﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace P211_ASP_Front.Models
{
    public class Summer
    {
        public int Id { get; set; }

        [StringLength(255)]
        public string LeftImage { get; set; }
        [StringLength(255)]
        public string LeftHeading { get; set; }
        [StringLength(500)]
        public string LeftContent { get; set; }

        [StringLength(255)]
        public string RightImage { get; set; }
        [StringLength(255)]
        public string RightHeading { get; set; }
        [StringLength(500)]
        public string RightContent { get; set; }
    }
}
