﻿using System.ComponentModel.DataAnnotations;

namespace P211_ASP_Front.Models
{
    public class ShipItem
    {
        public int Id { get; set; }

        [StringLength(100)]
        public string Icon { get; set; }

        [StringLength(100)]
        public string Title { get; set; }

        [StringLength(200)]
        public string Content { get; set; }

        public virtual Ship Ship { get; set; }
    }
}
