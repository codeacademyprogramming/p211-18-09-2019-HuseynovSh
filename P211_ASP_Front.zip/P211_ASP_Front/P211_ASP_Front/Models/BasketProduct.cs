﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP_Front.Models
{
    public class BasketProduct
    {
        public int Id { get; set; }
      
        public string Image { get; set; }
      
        public string Name { get; set; }
        public decimal Price { get; set; }
        public bool HasDiscount { get; set; }
        public decimal DiscountPrice { get; set; }
        public int Quantity { get; set; }
    }
}
