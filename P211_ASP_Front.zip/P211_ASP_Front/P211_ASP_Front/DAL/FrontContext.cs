﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using P211_ASP_Front.Models;

namespace P211_ASP_Front.DAL
{
    public class FrontContext : DbContext
    {
        public FrontContext(DbContextOptions<FrontContext> options) : base(options)
        {
        }

        public DbSet<Slider> Sliders { get; set; }
        public DbSet<ShipItem> ShipItems { get; set; }
        public DbSet<Ship> Ships { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Summer> Summers { get; set; }
        public DbSet<Statics> Statics { get; set; }
    }
}
