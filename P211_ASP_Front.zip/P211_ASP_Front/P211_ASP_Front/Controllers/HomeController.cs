﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P211_ASP_Front.Models;
using P211_ASP_Front.ViewModels;
using P211_ASP_Front.DAL;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;

namespace P211_ASP_Front.Controllers
{
    public class HomeController : Controller
    {
        private readonly FrontContext _context;

        public HomeController(FrontContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Sliders = _context.Sliders.ToList(),
                Ship = _context.Ships.Include(s => s.ShipItems).First(),
                Products = _context.Products.ToList(),
                Summers = _context.Summers.First(),
                Statics = _context.Statics.ToList()
            };

            return View(homeIndexVM);
        }

        public IActionResult About()
        {
            int? count = HttpContext.Session.GetInt32("count");

            if(count != null)
            {
                count++;
            }
            else
            {
                count = 1;
            }

            HttpContext.Session.SetInt32("count", (int)count);

            return View(count);
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
