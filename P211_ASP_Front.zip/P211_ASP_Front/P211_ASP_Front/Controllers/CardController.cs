﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using P211_ASP_Front.Models;
using P211_ASP_Front.ViewModels;
using P211_ASP_Front.DAL;
using Newtonsoft.Json;

namespace P211_ASP_Front.Controllers
{
    public class CardController : Controller
    {
        private readonly FrontContext _context;

        public CardController(FrontContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Add(int id)
        {
            Product product = await _context.Products.FindAsync(id);
            BasketProduct basketproduct = product;

            string card = HttpContext.Session.GetString("card");

            List<BasketProduct> products = new List<BasketProduct>();

            if (card != null)
            {
                products = JsonConvert.DeserializeObject<List<BasketProduct>>(card);
            }
            var selected = products.FirstOrDefault(p => p.Id == id);
            if (selected == null){
              products.Add(basketproduct);
            }
            else
            {
                selected.Quantity += 1;
            }

            string productsJSON = JsonConvert.SerializeObject(products);
            HttpContext.Session.SetString("card", productsJSON);

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Remove(int id)
        {
            string card = HttpContext.Session.GetString("card");

            List<Product> products = new List<Product>();

            if (card != null)
            {
                products = JsonConvert.DeserializeObject<List<Product>>(card);
            }

            Product product = products.FirstOrDefault(p => p.Id == id);
            products.Remove(product);

            string productsJSON = JsonConvert.SerializeObject(products);
            HttpContext.Session.SetString("card", productsJSON);

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Index()
        {
            string card = HttpContext.Session.GetString("card");

            List<BasketProduct> products = new List<BasketProduct>();

            if (card != null)
            {
                products = JsonConvert.DeserializeObject<List<BasketProduct>>(card);
            }

            return View(products);
        }
    }
}