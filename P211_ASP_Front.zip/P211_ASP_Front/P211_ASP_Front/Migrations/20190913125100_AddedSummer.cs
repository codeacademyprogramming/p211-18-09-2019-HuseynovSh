﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace P211_ASP_Front.Migrations
{
    public partial class AddedSummer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Summers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    LeftImage = table.Column<string>(maxLength: 255, nullable: true),
                    LeftHeading = table.Column<string>(maxLength: 255, nullable: true),
                    LeftContent = table.Column<string>(maxLength: 300, nullable: true),
                    RightImage = table.Column<string>(maxLength: 255, nullable: true),
                    RightHeading = table.Column<string>(maxLength: 255, nullable: true),
                    RightContent = table.Column<string>(maxLength: 300, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Summers", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Summers");
        }
    }
}
